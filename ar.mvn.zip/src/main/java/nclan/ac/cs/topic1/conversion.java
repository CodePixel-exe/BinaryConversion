package nclan.ac.cs.topic1;

import static nclan.ac.cs.topic1.conversion.conversions.runConversion;

public class conversion {
    /*public static void main(String[] args) {
        System.out.println("Conversion test program");
        runConversion();

    }*/
    public class conversions {
        public static String convertDecimalToBinary(int number) {
            return Integer.toString(number, 2);
        }

        public static String convertDecimalToHex(int number){
            return Integer.toString(number,16).toUpperCase();

        }
        public static int convertBinaryToDecimal(String number){
            return Integer.parseInt(number,2);
        }
        public static int convertHexToDecimal(String number){
            return Integer.parseInt(number, 16);
        }
        public static void runConversion(){
            System.out.println(padLeftZeros(convertDecimalToBinary(12), 8));
            System.out.println(convertDecimalToHex(62493));
            System.out.println(convertBinaryToDecimal("0011"));
            System.out.println(convertHexToDecimal("132A"));
        }
        public static String padLeftZeros (String inputString, int length) {
            if (inputString.length() >= length) {
                return inputString;
            }
            StringBuilder sb = new StringBuilder();
            while (sb.length() < length - inputString.length()) {
                sb.append(0);
            }
            sb.append(inputString);
            return sb.toString();
        }

    }
}

